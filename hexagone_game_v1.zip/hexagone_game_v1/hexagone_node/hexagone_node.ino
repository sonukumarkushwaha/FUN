/*
  HEXAGONE GAME - NODE firmware (ESP8266 / ESP-12E, "Hex_pcb" rev 1.0)
  ---------------------------------------------------------------------
  Board : "Generic ESP8266 Module" or "NodeMCU 1.0 (ESP-12E)"
  Libs  : Adafruit NeoPixel (Library Manager). Everything else is in the ESP8266 core.

  Hardware used (from schematic):
    PCF8574(A) @0x38 on I2C (SDA=GPIO4, SCL=GPIO5)
      P0..P3 -> 74HCT14 (inverting) -> MJD122 drivers -> ring LED strips (BJT_OUT connector)
      P4     -> 74HCT14 -> OUT5 (MAX485 DE/RE, not used here, kept in receive mode)
      P5     -> 74HCT14 -> OUT6 -> BC847 -> buzzer
    WS2812 center (20 LEDs) on GPIO0 (as in the old working firmware)
    HX711 load cell amp: DT=GPIO12, SCK=GPIO16 (through BSS138 level shifters)

  Same firmware on every node, nothing to set per node.
  ALL behaviour settings (hit sensitivity, beeps, flashes, idle patterns, timings ...) come
  from the master in every heartbeat, so they are changed on the master only ("set" command).
  The values in setDefaultConfig() are only used until the master is found.
  Center blinks red (rings off) until the master answers.
*/

#include <ESP8266WiFi.h>
#include <espnow.h>
#include <Wire.h>
#include <Adafruit_NeoPixel.h>
extern "C" {
#include <user_interface.h>
}

// ============================ HARDWARE CONFIG ============================
#define I2C_SDA_PIN       4
#define I2C_SCL_PIN       5
#define PCF8574_ADDR      0x38     // PCF8574A on the built boards (old firmware used 0x38)
// PCF pin LOW -> 74HCT14 output HIGH -> transistor ON. Set false if your board has no inverter.
#define PCF_ACTIVE_LOW    true

// PCF8574 bit for each ring channel (PCB OUTPUT1..4 = PCF P0..P3)
#define BIT_OUTER_BLUE    0        // OUTPUT1
#define BIT_MIDDLE_RED    1        // OUTPUT2
#define BIT_MIDDLE_BLUE   2        // OUTPUT3
#define BIT_OUTER_RED     3        // OUTPUT4
#define BIT_BUZZER        5

#define LED_PIN           0        // old firmware drove the WS2812 on GPIO0
#define LED_COUNT         20

#define HX_DT_PIN         12
#define HX_SCK_PIN        16
#define HX_WARMUP_SAMPLES 8

#define ESPNOW_CHANNEL    1        // must match master

// Local only (must work before / without a master)
#define HELLO_INTERVAL_MS      1000
#define MASTER_TIMEOUT_MS      3500   // no master packet this long -> not connected (blink red, leave game)
#define NO_LINK_BLINK_MS       500    // center red blink when not connected

#define DEBUG_LOADCELL         0      // 1 = print raw/delta to Serial (use Serial Plotter)

// ============================ PROTOCOL (keep identical in master) ============================
#define HEX_MAGIC  0xA7
#define MAX_NODES  20

enum MsgType : uint8_t {
  MSG_HELLO = 1, MSG_WELCOME = 2, MSG_IDLE = 3, MSG_START = 4,
  MSG_ROUND = 5, MSG_END = 6, MSG_HIT = 7
};
enum Role : uint8_t { ROLE_NONE = 0, ROLE_P1 = 1, ROLE_P2 = 2 };
enum Seg : uint8_t { SEG_OFF = 0, SEG_RED = 1, SEG_BLUE = 2, SEG_BOTH = 3 };
enum CColor : uint8_t { C_OFF, C_RED, C_BLUE, C_GREEN, C_PURPLE, C_YELLOW, C_CYAN, C_WHITE };
// look byte: bits0-1 outer ring, bits2-3 middle ring, bits4-6 center color, bit7 blink
#define MAKE_LOOK(outer, middle, center, blink) \
  (uint8_t)(((outer) & 3) | (((middle) & 3) << 2) | (((center) & 7) << 4) | ((blink) ? 0x80 : 0))

// Every node setting, sent by the master inside each WELCOME (heartbeat)
struct __attribute__((packed)) NodeConfig {
  int32_t  hitThreshold;   // load cell counts above baseline = hit
  uint16_t hitLockoutMs;   // ignore load cell after a hit
  uint8_t  hitRearmPct;    // re-arm when signal falls below this % of threshold
  uint8_t  baselineShift;  // baseline drift follow speed (EMA 1/2^n)
  uint16_t hitStuckMs;     // re-learn baseline if signal stays high this long
  uint8_t  brightness;     // center LED brightness
  uint8_t  buzzer;         // 0 = silent
  uint16_t hitBeepMs;
  uint16_t wrongBeepMs;
  uint16_t startBeepMs;
  uint16_t endBeepMs;
  uint16_t hitFlashMs;     // center green after correct hit
  uint16_t endDarkMs;      // game over: all dark this long
  uint16_t winnerBlinkMs;  // game over: outer ring blink speed
  uint16_t idleSlotMs;     // learned wall: each pattern runs this long
  uint16_t freeIdleMinMs;  // not learned: each node changes pattern after min..max
  uint16_t freeIdleMaxMs;
  uint16_t idleWallMask;   // enabled wall patterns (bit per pattern)
  uint8_t  idleFreeMask;   // enabled free patterns (bit per pattern)
  uint8_t  idleSpeedPct;   // animation speed, 100 = normal
};

struct __attribute__((packed)) MsgHeader  { uint8_t magic; uint8_t type; uint16_t seq; };
struct __attribute__((packed)) HelloMsg   { MsgHeader h; uint8_t slot; uint8_t state; uint8_t loadCellOk; int32_t loadRaw; };
struct __attribute__((packed)) WelcomeMsg { MsgHeader h; uint8_t mac[6]; uint8_t slot; uint32_t masterMs; uint8_t position; uint8_t flags; uint8_t wallCount; NodeConfig cfg; };
#define WFLAG_LEARN  0x01  // master is in position-learn mode
struct __attribute__((packed)) StartMsg   { MsgHeader h; uint16_t greenMs; uint16_t darkMs; };
struct __attribute__((packed)) RoundMsg   { MsgHeader h; uint16_t roundId; uint16_t durationMs; uint8_t look[MAX_NODES]; uint8_t role[MAX_NODES]; };
struct __attribute__((packed)) EndMsg     { MsgHeader h; uint8_t winner; uint16_t showMs; uint16_t score1; uint16_t score2; };
struct __attribute__((packed)) HitMsg     { MsgHeader h; uint8_t slot; uint16_t roundId; uint8_t role; int32_t strength; };
// ===========================================================================================

#define M_OUTER_RED    (1 << BIT_OUTER_RED)
#define M_OUTER_BLUE   (1 << BIT_OUTER_BLUE)
#define M_MIDDLE_RED   (1 << BIT_MIDDLE_RED)
#define M_MIDDLE_BLUE  (1 << BIT_MIDDLE_BLUE)
#define M_BUZZER       (1 << BIT_BUZZER)

enum NodeState : uint8_t { ST_IDLE = 0, ST_STARTING = 1, ST_GAME = 2, ST_END = 3 };

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

NodeConfig cfg;  // current settings (from master)

uint8_t BROADCAST_MAC[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
uint8_t myMac[6];
uint8_t masterMac[6];
bool masterKnown = false;
uint32_t lastMasterRx = 0;
uint8_t mySlot = 0xFF;
uint16_t txSeq = 0;

NodeState state = ST_IDLE;
uint32_t greenUntil = 0, endUntil = 0, endDarkUntil = 0, flashUntil = 0, buzzerUntil = 0;
uint8_t winner = 0;

// current round
bool roundActive = false;
uint16_t curRoundId = 0;
uint32_t curRoundRxAt = 0;
uint32_t roundEnd = 0;
uint8_t curLook = 0, curRole = ROLE_NONE;
bool hitThisRound = false;

// command de-dup (master repeats START/END/IDLE a few times)
uint8_t lastCmdType = 0;
uint16_t lastCmdSeq = 0;
uint32_t lastCmdAt = 0;

// load cell
int32_t baseline = 0, lastRaw = 0;
uint8_t hxWarmup = 0;
bool hitArmed = true;
uint32_t hitLockoutUntil = 0, hitDisarmedAt = 0, lastHxSample = 0;

// idle animation: clock shared with master so every node runs the same pattern at the same time
int32_t clockOffset = 0;
uint8_t myPos = 0;         // wall position 1..N from master (0 = not learned yet)
uint8_t wallCount = 0;     // how many hexagons were learned
bool learnMode = false;    // master is learning wall positions
#define WALL_PATTERNS 10
#define FREE_PATTERNS 6

int16_t lastPcf = -1;

// Defaults until the master sends its settings (keep in line with master defaults)
void setDefaultConfig() {
  cfg.hitThreshold  = 800;
  cfg.hitLockoutMs  = 250;
  cfg.hitRearmPct   = 50;
  cfg.baselineShift = 4;
  cfg.hitStuckMs    = 2000;
  cfg.brightness    = 150;
  cfg.buzzer        = 1;
  cfg.hitBeepMs     = 80;
  cfg.wrongBeepMs   = 300;
  cfg.startBeepMs   = 150;
  cfg.endBeepMs     = 500;
  cfg.hitFlashMs    = 200;
  cfg.endDarkMs     = 2000;
  cfg.winnerBlinkMs = 300;
  cfg.idleSlotMs    = 8000;
  cfg.freeIdleMinMs = 6000;
  cfg.freeIdleMaxMs = 12000;
  cfg.idleWallMask  = (1 << WALL_PATTERNS) - 1;
  cfg.idleFreeMask  = (1 << FREE_PATTERNS) - 1;
  cfg.idleSpeedPct  = 100;
}

// ---------------- RX queue (ESP-NOW callback -> loop) ----------------
struct RxPacket { uint8_t mac[6]; uint8_t len; uint8_t data[96]; };
#define RXQ_SIZE 8
RxPacket rxq[RXQ_SIZE];
volatile uint8_t rxHead = 0, rxTail = 0;

void onEspNowRecv(uint8_t *mac, uint8_t *data, uint8_t len) {
  uint8_t next = (rxHead + 1) % RXQ_SIZE;
  if (next == rxTail || len > sizeof(rxq[0].data)) return;  // full / too big
  memcpy(rxq[rxHead].mac, mac, 6);
  memcpy(rxq[rxHead].data, data, len);
  rxq[rxHead].len = len;
  rxHead = next;
}

// ============================ OUTPUTS ============================
void pcfWriteLogical(uint8_t on) {
  uint8_t out = PCF_ACTIVE_LOW ? (uint8_t)~on : on;
  if ((int16_t)out == lastPcf) return;
  Wire.beginTransmission(PCF8574_ADDR);
  Wire.write(out);
  if (Wire.endTransmission() == 0) lastPcf = out;
}

uint32_t colorOf(uint8_t c) {
  switch (c) {
    case C_RED:    return strip.Color(255, 0, 0);
    case C_BLUE:   return strip.Color(0, 0, 255);
    case C_GREEN:  return strip.Color(0, 255, 0);
    case C_PURPLE: return strip.Color(170, 0, 255);
    case C_YELLOW: return strip.Color(255, 170, 0);
    case C_CYAN:   return strip.Color(0, 255, 255);
    case C_WHITE:  return strip.Color(255, 255, 255);
    default:       return 0;
  }
}

void fillCenter(uint32_t color) {
  for (uint8_t i = 0; i < LED_COUNT; i++) strip.setPixelColor(i, color);
}

void beep(uint16_t ms) {
  if (cfg.buzzer && ms) buzzerUntil = millis() + ms;
}

uint8_t ringBits(uint8_t outer, uint8_t middle) {
  uint8_t on = 0;
  if (outer & SEG_RED)   on |= M_OUTER_RED;
  if (outer & SEG_BLUE)  on |= M_OUTER_BLUE;
  if (middle & SEG_RED)  on |= M_MIDDLE_RED;
  if (middle & SEG_BLUE) on |= M_MIDDLE_BLUE;
  return on;
}

// Shows a look on center LEDs, returns ring bits
uint8_t applyLook(uint8_t look, uint32_t now) {
  if ((look & 0x80) && ((now / 150) & 1)) {
    fillCenter(0);
    return 0;
  }
  fillCenter(colorOf((look >> 4) & 7));
  return ringBits(look & 3, (look >> 2) & 3);
}

// ============================ IDLE PATTERNS ============================
// Center palette for idle: colors that sit between / around the red and blue rings.
// "Warm" ones are paired with red rings, "cool" ones with blue rings.
const uint32_t WARM[] = {
  0xFF00A0,  // magenta
  0xFF1E5A,  // hot pink
  0xC800FF,  // purple
};
const uint32_t COOL[] = {
  0x00B4FF,  // cyan / sky blue
  0x6E00FF,  // violet
  0x8CAAFF,  // ice white
};
#define NUM_WARM (sizeof(WARM) / sizeof(WARM[0]))
#define NUM_COOL (sizeof(COOL) / sizeof(COOL[0]))

uint32_t dimmed(uint32_t c, uint8_t lvl) {
  return strip.Color(((c >> 16) & 0xFF) * lvl / 255, ((c >> 8) & 0xFF) * lvl / 255, (c & 0xFF) * lvl / 255);
}

// warm on even waves, cool on odd waves; the color itself changes each pair of waves
uint32_t waveColor(uint32_t wave, bool warm) {
  return warm ? WARM[(wave / 2) % NUM_WARM] : COOL[(wave / 2) % NUM_COOL];
}

// ---- wall layout (front view): hexagons in 3 staggered columns, numbered in reading order
// (works for any number learned, the pattern simply continues downwards):
//        left   middle   right
//        [ 1]            [ 2]
//               [ 3]
//        [ 4]            [ 5]
//               [ 6]
//         ...    ...      ...
// x = column (0 left, 1 middle, 2 right), y = height in half-rows (0 = top)
uint8_t posX(uint8_t p) { static const uint8_t X[3] = {0, 2, 1}; return X[(p - 1) % 3]; }
uint8_t posY(uint8_t p) { return ((p - 1) / 3) * 2 + ((p - 1) % 3 == 2 ? 1 : 0); }
uint8_t wallRows()      { return wallCount ? posY(wallCount) + 1 : 1; }  // height in half-rows

// Same looks as in the game
const uint8_t L_OFF  = 0;
const uint8_t L_RED  = MAKE_LOOK(SEG_RED,  SEG_RED,  C_RED,  0);  // all red
const uint8_t L_BLUE = MAKE_LOOK(SEG_BLUE, SEG_BLUE, C_BLUE, 0);  // all blue
const uint8_t L_RBR  = MAKE_LOOK(SEG_RED,  SEG_BLUE, C_RED,  0);  // red, blue, red
const uint8_t L_BRB  = MAKE_LOOK(SEG_BLUE, SEG_RED,  C_BLUE, 0);  // blue, red, blue

uint32_t wallClock(uint32_t now) { return now + clockOffset; }

// animation time scaled by the idle speed setting
uint32_t animTime(uint32_t t) { return (uint32_t)((uint64_t)t * cfg.idleSpeedPct / 100); }

uint32_t hash32(uint32_t x) {
  x *= 2654435761UL;
  x ^= x >> 15;
  x *= 0x2C1B3C6DUL;
  x ^= x >> 12;
  return x;
}

// k-th enabled bit of mask (k counts from 0), or 255 if mask is empty
uint8_t nthEnabled(uint16_t mask, uint8_t total, uint8_t k) {
  for (uint8_t i = 0; i < total; i++)
    if (mask & (1 << i)) { if (k == 0) return i; k--; }
  return 255;
}

uint8_t countEnabled(uint16_t mask, uint8_t total) {
  uint8_t n = 0;
  for (uint8_t i = 0; i < total; i++) if (mask & (1 << i)) n++;
  return n;
}

// --- complementary-color effects (all center LEDs one color) ---
uint8_t fxColorSweep(uint32_t t) {  // cyan -> violet -> purple -> magenta -> pink and back
  uint16_t tri = (t * 6) % 65536;
  uint16_t k = tri < 32768 ? tri : 65535 - tri;
  uint16_t hue = 32768 + k;
  fillCenter(strip.gamma32(strip.ColorHSV(hue, 255, 255)));
  return (hue > 49152) ? (M_OUTER_RED | M_MIDDLE_BLUE) : (M_OUTER_BLUE | M_MIDDLE_RED);
}

uint8_t fxBreathing(uint32_t t) {  // warm color + red rings, then cool color + blue rings
  uint32_t wave = t / 3000;
  bool warm = (wave & 1) == 0;
  uint8_t lvl = strip.gamma8(strip.sine8((uint8_t)((t % 3000) * 256 / 3000 + 192)));  // 0 -> peak -> 0
  fillCenter(dimmed(waveColor(wave, warm), lvl));
  if (lvl > 90) return warm ? (M_OUTER_RED | M_MIDDLE_RED) : (M_OUTER_BLUE | M_MIDDLE_BLUE);
  return 0;
}

uint8_t fxRippleOut(uint32_t t) {  // center flash -> middle ring -> outer ring
  uint32_t wave = t / 2400;
  uint32_t cycle = t % 2400;
  bool warm = (wave & 1) == 0;
  uint8_t lvl = (cycle < 600) ? strip.gamma8(255 - cycle * 255 / 600) : 0;
  fillCenter(dimmed(waveColor(wave, warm), lvl));
  if (cycle >= 300 && cycle < 700)  return warm ? M_MIDDLE_RED : M_MIDDLE_BLUE;
  if (cycle >= 700 && cycle < 1100) return warm ? M_OUTER_BLUE : M_OUTER_RED;
  return 0;
}

uint8_t fxHeartbeat(uint32_t t) {  // pink beat + red outer, violet beat + blue middle
  uint32_t cycle = t % 1400;
  if (cycle < 250) {
    fillCenter(dimmed(WARM[1], strip.gamma8(255 - cycle * 255 / 250)));
    return cycle < 150 ? M_OUTER_RED : 0;
  }
  if (cycle >= 300 && cycle < 600) {
    fillCenter(dimmed(COOL[1], strip.gamma8(220 - (cycle - 300) * 220 / 300)));
    return cycle < 450 ? M_MIDDLE_BLUE : 0;
  }
  fillCenter(0);
  return 0;
}

uint8_t fxStrobe(uint32_t t) {  // magenta + red rings x2, cyan + blue rings x2
  uint8_t ph = (t / 100) % 8;
  if (ph % 2) { fillCenter(0); return 0; }
  bool warm = ph < 4;
  fillCenter(dimmed(warm ? WARM[0] : COOL[0], 255));
  return warm ? (M_OUTER_RED | M_MIDDLE_RED) : (M_OUTER_BLUE | M_MIDDLE_BLUE);
}

// Idle before wall positions are learned: every node picks its own random pattern and timing.
// Free patterns: 0 look cycle, 1 color sweep, 2 breathing, 3 ripple, 4 heartbeat, 5 strobe
uint8_t renderFreeIdle(uint32_t now) {
  static uint8_t pat = 0;
  static uint32_t nextSwitch = 0, phase = 0;
  uint8_t n = countEnabled(cfg.idleFreeMask, FREE_PATTERNS);
  if (n == 0) { fillCenter(0); return 0; }  // all free patterns disabled -> dark
  if ((int32_t)(now - nextSwitch) >= 0 || !(cfg.idleFreeMask & (1 << pat))) {
    pat = nthEnabled(cfg.idleFreeMask, FREE_PATTERNS, random(n));
    phase = random(0, 60000);
    uint16_t lo = cfg.freeIdleMinMs, hi = cfg.freeIdleMaxMs;
    if (hi <= lo) hi = lo + 1;
    nextSwitch = now + random(lo, hi);
  }
  uint32_t t = animTime(now + phase);
  switch (pat) {
    case 0: {  // red-blue-red, blue-red-blue, off, all red, all blue, off
      static const uint8_t seq[6] = {L_RBR, L_BRB, L_OFF, L_RED, L_BLUE, L_OFF};
      return applyLook(seq[(t / 500) % 6], t);
    }
    case 1:  return fxColorSweep(t);
    case 2:  return fxBreathing(t);
    case 3:  return fxRippleOut(t);
    case 4:  return fxHeartbeat(t);
    default: return fxStrobe(t);
  }
}

// Wall positions learned: all nodes run the same pattern on the master clock.
// Wall patterns: 0 look cycle, 1 looks flowing down, 2 column sweep, 3 checkerboard, 4 rain,
//                5 color sweep down, 6 breathing, 7 ripple from middle, 8 heartbeat, 9 strobe
uint8_t renderIdle(uint32_t now) {
  if (myPos < 1 || myPos > wallCount) return renderFreeIdle(now);  // no "learn" done yet

  uint8_t n = countEnabled(cfg.idleWallMask, WALL_PATTERNS);
  if (n == 0) { fillCenter(0); return 0; }  // all wall patterns disabled -> dark

  uint32_t wt = wallClock(now);
  uint32_t slot = wt / (cfg.idleSlotMs ? cfg.idleSlotMs : 1);
  uint8_t k = hash32(slot) % n;
  if (n > 1 && k == hash32(slot - 1) % n) k = (k + 1) % n;  // no repeat back-to-back
  uint8_t pat = nthEnabled(cfg.idleWallMask, WALL_PATTERNS, k);

  uint32_t t = animTime(wt);
  uint8_t pos = myPos;
  uint8_t x = posX(pos), y = posY(pos);

  switch (pat) {
    case 0: {  // whole wall together: red-blue-red, blue-red-blue, off, all red, all blue, off
      static const uint8_t seq[6] = {L_RBR, L_BRB, L_OFF, L_RED, L_BLUE, L_OFF};
      return applyLook(seq[(t / 500) % 6], t);
    }
    case 1: {  // same looks flowing down the wall
      static const uint8_t seq[6] = {L_RED, L_RBR, L_BRB, L_BLUE, L_OFF, L_OFF};
      return applyLook(seq[(t / 300 + 6000 - y) % 6], t);
    }
    case 2: {  // column sweep left -> right in red, right -> left in blue
      uint8_t step = (t / 450) % 8;
      uint8_t col = step < 3 ? step : (step >= 4 && step < 7) ? 6 - step : 255;
      return applyLook(x == col ? (step < 4 ? L_RED : L_BLUE) : L_OFF, t);
    }
    case 3: {  // checkerboard of red-blue-red / blue-red-blue, swapping
      bool flip = ((pos & 1) != 0) ^ (((t / 600) & 1) != 0);
      return applyLook(flip ? L_RBR : L_BRB, t);
    }
    case 4: {  // rain: a lit row falls down the wall with a tail, red pass then blue pass
      uint8_t period = wallRows() + 4;  // fall through the whole wall + short pause
      uint8_t step = (t / 160) % period;
      bool red = ((t / (160UL * period)) & 1) == 0;
      if (y == step) return applyLook(red ? L_RED : L_BLUE, t);
      if (y + 1 == step) return applyLook(MAKE_LOOK(SEG_OFF, red ? SEG_RED : SEG_BLUE, red ? C_RED : C_BLUE, 0), t);
      return applyLook(L_OFF, t);
    }
    case 5:  // color sweep travelling down the wall
      return fxColorSweep(t - y * 500);
    case 6:  // whole wall breathing together
      return fxBreathing(t);
    case 7: {  // ripple spreading from the middle of the wall outwards
      uint32_t dist = abs((int)x - 1) * 3 + abs(2 * (int)y - (wallRows() - 1));
      return fxRippleOut(t - dist * 70);
    }
    case 8:  // whole wall heartbeat
      return fxHeartbeat(t);
    default:  // whole wall strobe
      return fxStrobe(t);
  }
}

// Game over: everything dark for endDarkMs, then only the OUTER ring blinks in the winner's color
uint8_t renderWinner(uint32_t now) {
  fillCenter(0);
  if ((int32_t)(now - endDarkUntil) < 0) return 0;
  bool phase = (now / (cfg.winnerBlinkMs ? cfg.winnerBlinkMs : 1)) & 1;
  uint8_t seg;
  if (winner == 1)      seg = phase ? SEG_RED : SEG_OFF;
  else if (winner == 2) seg = phase ? SEG_BLUE : SEG_OFF;
  else                  seg = phase ? SEG_RED : SEG_BLUE;  // draw: outer ring alternates red / blue
  return ringBits(seg, SEG_OFF);
}

void enterIdle() {
  state = ST_IDLE;
  roundActive = false;
}

// Connected = master answered recently and gave us a slot
bool isLinked(uint32_t now) {
  return masterKnown && mySlot < MAX_NODES && (now - lastMasterRx) < MASTER_TIMEOUT_MS;
}

void render(uint32_t now) {
  uint8_t on = 0;
  switch (state) {
    case ST_IDLE:
      if (!isLinked(now)) {  // not connected: only center blinks red, rings off
        fillCenter(((now / NO_LINK_BLINK_MS) & 1) ? colorOf(C_RED) : 0);
        break;
      }
      if (learnMode) {  // learning positions: learned = steady green, waiting = blinking white
        if (myPos) fillCenter(colorOf(C_GREEN));
        else       fillCenter(((now / 300) & 1) ? colorOf(C_WHITE) : 0);
      } else {
        on = renderIdle(now);
      }
      if ((int32_t)(now - flashUntil) < 0) {  // hit in idle: same green flash as in game
        fillCenter(colorOf(C_GREEN));
        on = 0;
      }
      break;

    case ST_STARTING:
      if ((int32_t)(now - greenUntil) < 0) {
        fillCenter(colorOf(C_GREEN));
      } else {
        fillCenter(0);
        state = ST_GAME;
      }
      break;

    case ST_GAME:
      if (roundActive && (int32_t)(now - roundEnd) >= 0) roundActive = false;
      if (!roundActive)      fillCenter(0);
      else if (hitThisRound) fillCenter((int32_t)(now - flashUntil) < 0 ? colorOf(C_GREEN) : 0);  // green flash, rings off
      else                   on = applyLook(curLook, now);
      break;

    case ST_END:
      if ((int32_t)(now - endUntil) >= 0) {
        enterIdle();
        on = renderIdle(now);
      } else {
        on = renderWinner(now);
      }
      break;
  }
  if ((int32_t)(now - buzzerUntil) < 0) on |= M_BUZZER;
  pcfWriteLogical(on);
  strip.show();
}

// ============================ ESP-NOW ============================
void fillHeader(MsgHeader &h, uint8_t type) {
  h.magic = HEX_MAGIC;
  h.type = type;
  h.seq = ++txSeq;
}

// Unicast while connected; broadcast otherwise so a rebooted/replaced master still finds us
void sendToMaster(void *msg, uint8_t len) {
  esp_now_send(isLinked(millis()) ? masterMac : BROADCAST_MAC, (uint8_t *)msg, len);
}

void learnMaster(const uint8_t *mac) {
  if (masterKnown && memcmp(mac, masterMac, 6) == 0) return;
  if (masterKnown) esp_now_del_peer(masterMac);
  memcpy(masterMac, mac, 6);
  esp_now_add_peer(masterMac, ESP_NOW_ROLE_COMBO, ESPNOW_CHANNEL, NULL, 0);
  masterKnown = true;
  Serial.printf("Master: %02X:%02X:%02X:%02X:%02X:%02X\n", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

void sendHello() {
  HelloMsg m;
  fillHeader(m.h, MSG_HELLO);
  m.slot = mySlot;
  m.state = state;
  m.loadCellOk = (millis() - lastHxSample) < 1000;
  m.loadRaw = lastRaw;
  sendToMaster(&m, sizeof(m));
}

void sendHit(uint8_t role, int32_t strength) {
  if (!masterKnown || mySlot >= MAX_NODES) return;
  HitMsg m;
  fillHeader(m.h, MSG_HIT);
  m.slot = mySlot;
  m.roundId = curRoundId;
  m.role = role;
  m.strength = strength;
  sendToMaster(&m, sizeof(m));
}

bool isDuplicateCmd(const MsgHeader *h, uint32_t now) {
  if (h->type == lastCmdType && h->seq == lastCmdSeq && now - lastCmdAt < 1000) return true;
  lastCmdType = h->type;
  lastCmdSeq = h->seq;
  lastCmdAt = now;
  return false;
}

void handlePacket(const uint8_t *mac, const uint8_t *data, uint8_t len) {
  if (len < sizeof(MsgHeader)) return;
  const MsgHeader *h = (const MsgHeader *)data;
  if (h->magic != HEX_MAGIC) return;
  if (h->type == MSG_HELLO || h->type == MSG_HIT) return;  // other nodes' traffic

  uint32_t now = millis();
  learnMaster(mac);
  lastMasterRx = now;

  switch (h->type) {
    case MSG_WELCOME: {
      if (len < sizeof(WelcomeMsg)) {
        static uint32_t lastWarn = 0;
        if (now - lastWarn > 3000) {
          lastWarn = now;
          Serial.printf("Master answered with %u bytes, expected %u -> master and node firmware are different versions, re-upload both\n",
                        len, (unsigned)sizeof(WelcomeMsg));
        }
        return;
      }
      const WelcomeMsg *w = (const WelcomeMsg *)data;
      if (memcmp(w->mac, myMac, 6) != 0) return;  // not for me
      if (w->slot != mySlot) Serial.printf("Assigned slot %u\n", w->slot);
      mySlot = w->slot;
      clockOffset = (int32_t)(w->masterMs - now);  // share master clock for synced idle
      if (w->position != myPos) Serial.printf("Wall position %u\n", w->position);
      myPos = (w->position <= MAX_NODES) ? w->position : 0;
      wallCount = w->wallCount;
      learnMode = (w->flags & WFLAG_LEARN) != 0;
      if (w->cfg.brightness != cfg.brightness) strip.setBrightness(w->cfg.brightness);
      memcpy(&cfg, &w->cfg, sizeof(cfg));  // all settings from master
    } break;

    case MSG_IDLE:
      if (isDuplicateCmd(h, now)) return;
      enterIdle();
      break;

    case MSG_START: {
      if (len < sizeof(StartMsg) || isDuplicateCmd(h, now)) return;
      const StartMsg *s = (const StartMsg *)data;
      state = ST_STARTING;
      roundActive = false;
      greenUntil = now + s->greenMs;
      beep(cfg.startBeepMs);
      Serial.println("START");
    } break;

    case MSG_ROUND: {
      if (len < sizeof(RoundMsg)) return;
      const RoundMsg *r = (const RoundMsg *)data;
      if (r->roundId == curRoundId && now - curRoundRxAt < 2000) return;  // repeated copy
      curRoundId = r->roundId;
      curRoundRxAt = now;
      state = ST_GAME;  // also lets a node that rebooted mid-game rejoin
      if (mySlot >= MAX_NODES) return;
      curLook = r->look[mySlot];
      curRole = r->role[mySlot];
      roundEnd = now + r->durationMs;
      roundActive = true;
      hitThisRound = false;
    } break;

    case MSG_END: {
      if (len < sizeof(EndMsg) || isDuplicateCmd(h, now)) return;
      const EndMsg *e = (const EndMsg *)data;
      state = ST_END;
      roundActive = false;
      winner = e->winner;
      endDarkUntil = now + cfg.endDarkMs;
      endUntil = endDarkUntil + e->showMs;
      beep(cfg.endBeepMs);
      Serial.printf("END  P1=%u  P2=%u  winner=%u\n", e->score1, e->score2, e->winner);
    } break;
  }
}

// ============================ LOAD CELL (HX711) ============================
int32_t hxRead() {
  uint32_t v = 0;
  noInterrupts();
  for (uint8_t i = 0; i < 24; i++) {
    digitalWrite(HX_SCK_PIN, HIGH);
    delayMicroseconds(2);
    v = (v << 1) | (digitalRead(HX_DT_PIN) ? 1 : 0);
    digitalWrite(HX_SCK_PIN, LOW);
    delayMicroseconds(2);
  }
  // 25th pulse -> channel A, gain 128 for next conversion
  digitalWrite(HX_SCK_PIN, HIGH);
  delayMicroseconds(2);
  digitalWrite(HX_SCK_PIN, LOW);
  interrupts();
  if (v & 0x800000) v |= 0xFF000000;  // sign extend
  return (int32_t)v;
}

void onHit(int32_t strength, uint32_t now) {
  if (state == ST_GAME && roundActive && !hitThisRound && curRole != ROLE_NONE) {
    hitThisRound = true;
    flashUntil = now + cfg.hitFlashMs;
    beep(cfg.hitBeepMs);
    sendHit(curRole, strength);
    Serial.printf("HIT! role=%u strength=%ld\n", curRole, (long)strength);
  } else if (state == ST_GAME && roundActive && !hitThisRound && curLook != 0) {
    beep(cfg.wrongBeepMs);  // hit a decoy
    sendHit(ROLE_NONE, strength);
    Serial.printf("Wrong hit (decoy) strength=%ld\n", (long)strength);
  } else if (state == ST_IDLE) {
    flashUntil = now + cfg.hitFlashMs;
    beep(cfg.hitBeepMs);
    sendHit(ROLE_NONE, strength);  // master prints it -> handy for threshold tuning
    Serial.printf("Idle hit strength=%ld\n", (long)strength);
  }
}

void loadCellTask(uint32_t now) {
  if (digitalRead(HX_DT_PIN) != LOW) return;  // conversion not ready
  int32_t raw = hxRead();
  lastRaw = raw;
  lastHxSample = now;

  if (hxWarmup < HX_WARMUP_SAMPLES) {
    baseline = raw;
    hxWarmup++;
    return;
  }

  int32_t delta = abs(raw - baseline);

#if DEBUG_LOADCELL
  Serial.printf("raw:%ld delta:%ld thr:%ld\n", (long)raw, (long)delta, (long)cfg.hitThreshold);
#endif

  if (hitArmed) {
    if (delta > cfg.hitThreshold && (int32_t)(now - hitLockoutUntil) >= 0) {
      hitArmed = false;
      hitDisarmedAt = now;
      hitLockoutUntil = now + cfg.hitLockoutMs;
      onHit(delta, now);
    } else {
      baseline += (raw - baseline) >> cfg.baselineShift;  // follow slow drift only while quiet
    }
  } else {
    if ((int32_t)(now - hitLockoutUntil) >= 0 && delta < cfg.hitThreshold * cfg.hitRearmPct / 100) {
      hitArmed = true;  // signal settled, ready for next hit
    } else if (now - hitDisarmedAt > cfg.hitStuckMs) {
      baseline = raw;   // load changed permanently (someone leaning etc.) -> re-learn
      hitArmed = true;
    }
  }
}

// ============================ SETUP / LOOP ============================
void setup() {
  Serial.begin(115200);
  delay(50);
  setDefaultConfig();

  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  Wire.setClock(100000);  // PCF8574 is a 100 kHz part
  pcfWriteLogical(0);  // everything off ASAP
  Wire.beginTransmission(PCF8574_ADDR);
  if (Wire.endTransmission() != 0) {  // rings can't work without it: show what is on the bus
    Serial.printf("\nPCF8574 NOT found at 0x%02X! I2C devices found:", PCF8574_ADDR);
    for (uint8_t a = 1; a < 127; a++) {
      Wire.beginTransmission(a);
      if (Wire.endTransmission() == 0) Serial.printf(" 0x%02X", a);
    }
    Serial.println("  -> set PCF8574_ADDR to the address above");
  }

  strip.begin();
  strip.setBrightness(cfg.brightness);
  strip.clear();
  strip.show();

  pinMode(HX_DT_PIN, INPUT);
  pinMode(HX_SCK_PIN, OUTPUT);
  digitalWrite(HX_SCK_PIN, LOW);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  WiFi.setSleepMode(WIFI_NONE_SLEEP);
  wifi_set_channel(ESPNOW_CHANNEL);
  WiFi.macAddress(myMac);

  if (esp_now_init() != 0) {
    Serial.println("ESP-NOW init failed, restarting");
    delay(1000);
    ESP.restart();
  }
  esp_now_set_self_role(ESP_NOW_ROLE_COMBO);
  esp_now_register_recv_cb(onEspNowRecv);
  esp_now_add_peer(BROADCAST_MAC, ESP_NOW_ROLE_COMBO, ESPNOW_CHANNEL, NULL, 0);

  randomSeed(ESP.getChipId() ^ micros());

  Serial.printf("\nHexagone node  MAC %s\n", WiFi.macAddress().c_str());
}

void loop() {
  uint32_t now = millis();

  while (rxTail != rxHead) {
    handlePacket(rxq[rxTail].mac, rxq[rxTail].data, rxq[rxTail].len);
    rxTail = (rxTail + 1) % RXQ_SIZE;
  }

  loadCellTask(now);

  static bool wasLinked = false;
  bool linked = isLinked(now);
  if (linked != wasLinked) {
    wasLinked = linked;
    Serial.println(linked ? "Connected to master" : "Master lost");
    if (!linked && state != ST_IDLE) enterIdle();
  }

  static uint32_t nextHello = 0;
  if ((int32_t)(now - nextHello) >= 0) {
    sendHello();
    nextHello = now + HELLO_INTERVAL_MS + random(0, 200);
  }

  static uint32_t nextFrame = 0;
  if ((int32_t)(now - nextFrame) >= 0) {
    nextFrame = now + 20;  // 50 fps
    render(now);
  }
}
